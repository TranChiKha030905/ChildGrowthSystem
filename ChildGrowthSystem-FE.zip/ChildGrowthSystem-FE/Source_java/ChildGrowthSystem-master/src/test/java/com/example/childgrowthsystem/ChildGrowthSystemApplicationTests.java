package com.example.childgrowthsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChildGrowthSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
