package com.example.childgrowthsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChildGrowthSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChildGrowthSystemApplication.class, args);
    }

}
